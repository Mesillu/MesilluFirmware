# ⬡ MESILLU FIRMWARE
### Code Snippet Repository — Vercel Deployment

---

## 🚀 Deploy in 3 Steps

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "init: mesillu firmware repository"
git remote add origin https://github.com/YOUR_USERNAME/mesillu-firmware.git
git push -u origin main
```

### 2. Deploy to Vercel
1. Go to [vercel.com](https://vercel.com) → **New Project**
2. Import your GitHub repo
3. Click **Deploy** (no build config needed)

### 3. Set Environment Variables
In Vercel dashboard → **Settings → Environment Variables**:

| Key | Value | Environment |
|-----|-------|-------------|
| `ADMIN_KEY` | `your-secret-password` | Production |

> ⚠️ Default admin key is `mesillu-admin-2024` — **change this immediately in production!**

---

## 📂 File Structure

```
/mesillu-firmware
├─ /api
│   └─ snippets.js       ← Serverless API (GET/POST/DELETE)
├─ /css
│   └─ style.css         ← Dark cyberpunk theme
├─ /js
│   └─ main.js           ← Frontend logic
├─ index.html            ← Public visitor page
├─ admin.html            ← Hidden admin panel (not in nav)
├─ vercel.json           ← Vercel routing & config
├─ package.json          ← Dependencies (better-sqlite3)
└─ .gitignore
```

---

## 🔐 Admin Access

- URL: `yoursite.com/admin.html` (not linked from nav)
- Login with your `ADMIN_KEY` env variable
- Admin can: **add** and **delete** snippets
- Session stored in `sessionStorage` (cleared on tab close)

---

## 🗄️ Database Notes

SQLite is used via `better-sqlite3`. On Vercel, the DB lives in `/tmp` (ephemeral — resets on cold starts / redeployment). 

**For persistent production data**, migrate to:
- **Vercel Postgres** (Neon) — drop-in SQL replacement
- **PlanetScale** — MySQL serverless
- **Vercel KV** — Redis key-value store

The seed data in `api/snippets.js` auto-populates 3 sample snippets on first load.

---

## 🛡️ Security Features

- Admin URL not linked from any navigation
- Backend validates `x-admin-key` header on all write operations
- `noindex, nofollow` headers on `/admin.html`
- Rate limiting: **5 requests per IP per 60 seconds**
- Session key stored in `sessionStorage` (not `localStorage`)

---

## 🎨 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | Vanilla HTML/CSS/JS |
| Syntax Highlighting | Prism.js |
| Backend | Vercel Serverless (Node 18) |
| Database | SQLite via `better-sqlite3` |
| Hosting | Vercel |

---

## ⚙️ Local Development

```bash
npm install -g vercel
npm install
vercel dev
```

Then visit:
- `http://localhost:3000` → visitor page
- `http://localhost:3000/admin.html` → admin panel

Set local env:
```bash
export ADMIN_KEY=your-secret-key
```
